prompt --application/shared_components/security/authorizations/ivz_rights
begin
--   Manifest
--     SECURITY SCHEME: IVZ_Rights
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>29900289957549995
,p_default_application_id=>155
,p_default_id_offset=>43238802132961317
,p_default_owner=>'WKSP_OACINTERNSHIP'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(55139252853636973)
,p_name=>'IVZ_Rights'
,p_scheme_type=>'NATIVE_FUNCTION_BODY'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'	l_usr_type VARCHAR2(20);',
'BEGIN',
'	SELECT UPPER(USER_TYPE_NAME) INTO l_usr_type ',
'	FROM IVZ_USER_TYPE_MST',
'	WHERE USER_TYPE_ID = (SELECT USER_TYPE_ID FROM IVZ_USER_MST WHERE UPPER(USERNAME) = UPPER(:APP_USER));',
'',
'	IF NVL(l_usr_type,''X'') = l_usr_type THEN',
'		--HTP.P(''TRUE'');',
'		RETURN TRUE;',
'	ELSE',
'		--HTP.P(''FALSE'');',
'		RETURN FALSE;',
'	END IF; ',
'END;'))
,p_version_scn=>1
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
