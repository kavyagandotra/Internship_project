prompt --application/shared_components/navigation/lists/create_user_wizard_list
begin
--   Manifest
--     LIST: Create User Wizard List
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>29900289957549995
,p_default_application_id=>155
,p_default_id_offset=>43238802132961317
,p_default_owner=>'WKSP_OACINTERNSHIP'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(56151400978639500)
,p_name=>'Create User Wizard List'
,p_list_status=>'PUBLIC'
,p_version_scn=>1
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(56151531502639503)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Create User Type'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(56151916190639508)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Create User'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
