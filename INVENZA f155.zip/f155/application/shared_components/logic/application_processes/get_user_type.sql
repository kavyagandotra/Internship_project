prompt --application/shared_components/logic/application_processes/get_user_type
begin
--   Manifest
--     APPLICATION PROCESS: Get User Type
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>29900289957549995
,p_default_application_id=>155
,p_default_id_offset=>43238802132961317
,p_default_owner=>'WKSP_OACINTERNSHIP'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(81136487954266439)
,p_process_sequence=>1
,p_process_point=>'AFTER_LOGIN'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Get User Type'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'BEGIN',
'    SELECT USER_TYPE_CODE INTO :APP_USER_TYPE',
'    FROM IVZ_USER_TYPE_MST',
'    WHERE USER_TYPE_ID = (SELECT USER_TYPE_ID FROM IVZ_USER_MST WHERE LOWER(USERNAME) = LOWER(:APP_USER));',
'END;'))
,p_process_clob_language=>'PLSQL'
,p_version_scn=>39409883830544
);
wwv_flow_imp.component_end;
end;
/
