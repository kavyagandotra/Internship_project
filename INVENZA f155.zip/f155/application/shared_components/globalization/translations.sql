prompt --application/shared_components/globalization/translations
begin
--   Manifest
--     TRANSLATIONS: 155
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>29900289957549995
,p_default_application_id=>155
,p_default_id_offset=>43238802132961317
,p_default_owner=>'WKSP_OACINTERNSHIP'
);
null;
wwv_flow_imp.component_end;
end;
/
