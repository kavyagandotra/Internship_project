prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 155
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>29900289957549995
,p_default_application_id=>155
,p_default_id_offset=>43238802132961317
,p_default_owner=>'WKSP_OACINTERNSHIP'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(55024966252358786)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_version_identifier=>'24.1'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_current_theme_style_id=>wwv_flow_imp.id(60764623974891555)
,p_default_page_template=>wwv_flow_imp.id(54781771382358567)
,p_default_dialog_template=>wwv_flow_imp.id(54791755423358572)
,p_error_template=>wwv_flow_imp.id(54789194452358571)
,p_printer_friendly_template=>wwv_flow_imp.id(54781771382358567)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(54789194452358571)
,p_default_button_template=>wwv_flow_imp.id(54939704786358669)
,p_default_region_template=>wwv_flow_imp.id(54866572710358615)
,p_default_chart_template=>wwv_flow_imp.id(54866572710358615)
,p_default_form_template=>wwv_flow_imp.id(54866572710358615)
,p_default_reportr_template=>wwv_flow_imp.id(54866572710358615)
,p_default_tabform_template=>wwv_flow_imp.id(54866572710358615)
,p_default_wizard_template=>wwv_flow_imp.id(54866572710358615)
,p_default_menur_template=>wwv_flow_imp.id(54878925287358622)
,p_default_listr_template=>wwv_flow_imp.id(54866572710358615)
,p_default_irr_template=>wwv_flow_imp.id(54856708740358611)
,p_default_report_template=>wwv_flow_imp.id(54904786882358640)
,p_default_label_template=>wwv_flow_imp.id(54937210960358664)
,p_default_menu_template=>wwv_flow_imp.id(54941366517358670)
,p_default_calendar_template=>wwv_flow_imp.id(54941469166358672)
,p_default_list_template=>wwv_flow_imp.id(54927133171358655)
,p_default_nav_list_template=>wwv_flow_imp.id(54935912729358662)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(54935912729358662)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(54934104782358660)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(54802758370358582)
,p_default_dialogr_template=>wwv_flow_imp.id(54799981250358581)
,p_default_option_label=>wwv_flow_imp.id(54937210960358664)
,p_default_required_label=>wwv_flow_imp.id(54938543746358665)
,p_default_navbar_list_template=>wwv_flow_imp.id(54933740467358660)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/24.1/')
,p_files_version=>72
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
