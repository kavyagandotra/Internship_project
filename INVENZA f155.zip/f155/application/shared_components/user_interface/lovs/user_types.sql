prompt --application/shared_components/user_interface/lovs/user_types
begin
--   Manifest
--     USER TYPES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.5'
,p_default_workspace_id=>29900289957549995
,p_default_application_id=>155
,p_default_id_offset=>43238802132961317
,p_default_owner=>'WKSP_OACINTERNSHIP'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(56205514670790171)
,p_lov_name=>'USER TYPES'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'IVZ_USER_TYPE_MST'
,p_return_column_name=>'USER_TYPE_ID'
,p_display_column_name=>'USER_TYPE_NAME'
,p_default_sort_column_name=>'USER_TYPE_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
